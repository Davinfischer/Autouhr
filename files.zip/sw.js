const CACHE = 'rundenuhr-v10';
const FILES = ['./', './index.html', './manifest.webmanifest', './icons/icon.svg', './icons/favicon.ico',
  './icons/icon-192.png', './icons/icon-512.png', './icons/icon-maskable-192.png', './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png', './icons/apple-touch-icon-120.png', './icons/apple-touch-icon-152.png', './icons/apple-touch-icon-167.png', './icons/favicon-32.png'];
self.addEventListener('install', e => e.waitUntil(caches.open(CACHE).then(c => c.addAll(FILES)).then(() => self.skipWaiting())));
self.addEventListener('activate', e => e.waitUntil(
  caches.keys().then(k => Promise.all(k.filter(n => n !== CACHE).map(n => caches.delete(n)))).then(() => self.clients.claim())));
self.addEventListener('fetch', e => e.respondWith(caches.match(e.request).then(r => r || fetch(e.request))));
